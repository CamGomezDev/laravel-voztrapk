<?php $__env->startSection('seccion'); ?>
<script type="text/javascript" src="<?php echo e(asset('js/visitas.js')); ?>"></script>
<div class="panel panel-default">
	<div class="panel-heading" id="head">
		<h4>Visitas</h4>
	</div>
	<div class="panel-body">
    <?php $import = false; $alt = false; $panelsup = ['Visitas','Visitas','visitas','Visita']; ?>
    <?php echo $__env->make('inc.panel-sup', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php if($totRows > 0): ?>
      <?php $__currentLoopData = $municipios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $municipio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="well well-sm" data-toggle="collapse" href="#collapse<?php echo e($municipio->id); ?>" style="border: 1px solid rgb(190, 190, 190)">
        <b><?php echo e($municipio->nombre); ?> - Visitas: <?php echo e((count($municipio->visitas)) ? count($municipio->visitas) : 0); ?></b>
        <div class="table-responsive collapse" id="collapse<?php echo e($municipio->id); ?>" style="margin-top:15px">
          <table class="table table-striped table-bordered" style="margin-bottom: 0px">
            <thead>
              <tr>
                <th>Notas</th>
                <th>LLegada</th>
                <th>Salida</th>
                <th>Acciones</th>
              </tr>
            </thead>
            <tbody>
            <?php if(count($municipio->visitas) > 0): ?>
              <?php $__currentLoopData = $municipio->visitas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($visita->notas); ?></td>
                <td><?php echo e($visita->llegada); ?></td>
                <td><?php echo e($visita->salida); ?></td>
                <td style="text-align: center">
                  <h4 style="margin: 0;">
                    <a type="button" data-toggle="modal" data-target="#ModalActualizar"
                      data-id=          "<?php echo e($visita->id); ?>"
                      data-notas=       "<?php echo e($visita->notas); ?>"
                      data-llegada=     "<?php echo e($visita->llegada); ?>"
                      data-salida=      "<?php echo e($visita->salida); ?>"
                      data-id_municipio="<?php echo e($visita->id_municipio); ?>"><i class="fa fa-pencil-square-o" aria-hidden="true" style="margin-right: 10px"></i></a>
                    <a type="button" data-toggle="modal" data-target="#ModalEliminar" data-id="<?php echo e($visita->id); ?>"><i class="fa fa-trash-o" aria-hidden="true"></i></a>
                  </h4>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
              <tr>
                <td colspan=4>No se encontraron resultados</td>
              </tr>
            <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
        
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php
      $queryString = [];
      if (isset($_GET['q'])) {
        $queryString['q'] = $_GET['q'];
      } if (isset($_GET['rows'])) {
        $queryString['rows'] = $_GET['rows'];
      } if (isset($_GET['page'])) {
        $queryString['page'] = $_GET['page'];
      }
      ?>
      <?php echo e($municipios->appends($queryString)->links()); ?>

      <?php echo $__env->make('inc.filas', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php else: ?>
    <div class="well well-sm"><b>No se encontraron resultados</b></div>
    <?php endif; ?>
  </div>
</div>

<!-- Modal - Crear -->
<div class="modal fade" id="ModalCrear" role="dialog">
  <div class="modal-dialog modal-sm" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Nueva visita</h4>
      </div>
      <?php echo Form::open(['action' => 'VisitasController@store', 'method' => 'POST']); ?>

        <div class="modal-body">
          <div class="form-group">
            <?php echo e(Form::label('', 'Notas')); ?>

            <?php echo e(Form::text('notas', '', ['class' => 'form-control', 'required'])); ?>

            <?php echo e(Form::label('', 'Fecha de entrada')); ?>

            <?php echo e(Form::date('llegada', \Carbon\Carbon::now(), ['class' => 'form-control', 'required'])); ?>

            <?php echo e(Form::label('', 'Fecha de salida')); ?>

            <?php echo e(Form::date('salida', \Carbon\Carbon::now(), ['class' => 'form-control', 'required'])); ?>

            <?php echo e(Form::label('', 'Municipio')); ?>

            <?php echo e(Form::select('id_municipio', $municipiosInput, null, ['class' => 'form-control', 'placeholder' => 'Seleccionar municipio...', 'required'])); ?>

          </div>
        </div>
        <div class="modal-footer">
          <?php echo e(Form::submit('Crear', ['class' => 'btn btn-danger'])); ?>

        </div>
      <?php echo Form::close(); ?>

    </div>
  </div>
</div>

<!-- Modal - Actualizar -->
<div class="modal fade" id="ModalActualizar" role="dialog">
  <div class="modal-dialog modal-sm" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Actualizar Visita</h4>
      </div>
      <?php echo Form::open(['action' => ['VisitasController@update', 1], 'method' => 'POST']); ?>

        <div class="modal-body">
          <div class="form-group">
            <?php echo e(Form::hidden('id', '', ['id' => 'idInput'])); ?>

            <?php echo e(Form::label('', 'Notas')); ?>

            <?php echo e(Form::text('notas', '', ['id' => 'notasInput', 'class' => 'form-control', 'required'])); ?>

            <?php echo e(Form::label('', 'Fecha de entrada')); ?>

            <?php echo e(Form::date('llegada', \Carbon\Carbon::now(), ['id' => 'llegadaInput', 'class' => 'form-control', 'required'])); ?>

            <?php echo e(Form::label('', 'Fecha de salida')); ?>

            <?php echo e(Form::date('salida', \Carbon\Carbon::now(), ['id' => 'salidaInput', 'class' => 'form-control', 'required'])); ?>

            <?php echo e(Form::label('', 'Municipio')); ?>

            <?php echo e(Form::select('id_municipio', $municipiosInput, null, ['id' => 'id_municipioInput', 'class' => 'form-control', 'placeholder' => 'Seleccionar municipio...', 'required'])); ?>

            <?php echo e(Form::hidden('ruta', url()->current()."?".http_build_query($_GET))); ?>

            <?php echo e(Form::hidden('_method', 'PUT')); ?>

          </div>
        </div>
        <div class="modal-footer">
          <?php echo e(Form::submit('Actualizar', ['class' => 'btn btn-danger'])); ?>

        </div>
      <?php echo Form::close(); ?>

    </div>
  </div>
</div>

<!-- Modal - Eliminar -->
<div class="modal fade" id="ModalEliminar" role="dialog">
  <div class="modal-dialog modal-sm" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Eliminar Visita</h4>
      </div>
      <?php echo Form::open(['action' => 'VisitasController@destroy', 'method' => 'POST']); ?>

        <div class="modal-body">
	      	<p>¿Seguro que desea eliminar?</p>
	      	<?php echo e(Form::hidden('id', '', ['id' => 'idInput'])); ?>

          <?php echo e(Form::hidden('ruta', url()->current()."?".http_build_query($_GET))); ?>

	      </div>
        <?php echo e(Form::hidden('_method', 'DELETE')); ?>

        <div class="modal-footer">
          <?php echo e(Form::submit('Sí', ['class' => 'btn btn-danger'])); ?>

        </div>
      <?php echo Form::close(); ?>

    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('pags.administracion', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>