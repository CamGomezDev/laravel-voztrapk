<?php $__env->startSection('content'); ?>

<div class="container">
  <div class="panel panel-default">
    <div class="panel-body">
      <div class="row" style="margin-bottom: 15px">
        <div class="pull-left" style="margin-left:15px">
          <input type="text" class="form-control " id="busquedaMapa" placeholder="Buscar comuna" />
          <div id="divBusqRes" class="dropdown">
            <ul id="cuadroResul" class="dropdown-menu">
            </ul>
          </div>
        </div>
        <button id="irabajo" type="button" class="btn btn-custom pull-right" style="margin-right:15px;">Ir abajo</button>
      </div>
      <div class="row">
        <?php if($idcom): ?>
        <div class="col-md-8">
        <?php endif; ?>
          <div class="table-responsive" style="text-align: center; margin-left: 0px; margin-right: 0px">
            <object id='med_svg' data='<?php echo e(asset('svg/map_med_solo.svg')); ?>' type='image/svg+xml'></object>
          </div>
        <?php if($idcom): ?>
        </div>
        <hr class="style-one" id="inicioTablas" style="margin: 15px 0px 15px 0px">
        <div class="col-md-4">
          <div style="margin-left: 0px ; margin-right: 0px">
            <div class="vcenter-parent" style="margin:0px 0px 10px 0px">
              <h4 class="vcenter-parent pull-left">
                &nbsp<?php echo e($comuna->nombre); ?>

              </h4>
              <div class="vcenter-parent pull-right" style="margin-left:auto;">
                <button type="button" class="btn btn-custom" data-toggle="modal" data-target="#ModalComuna"
                  data-id     ="<?php echo e($comuna->id); ?>" 
                  data-puestos="<?php echo e($comuna->puestos); ?>"
                  data-barrios="<?php echo e($comuna->barrios); ?>"
                  data-mesas  ="<?php echo e($comuna->mesas); ?>">Editar</button>
              </div>
            </div>
            <div class="table-responsive">
              <table class="table table-striped table-bordered" style="margin-bottom: 0px">
                <thead>
                  <tr>
                    <th>Puestos</th>
                    <th>Barrios</th>
                    <th>Mesas</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td><?php echo e($comuna->puestos); ?></td>
                    <td><?php echo e($comuna->barrios); ?></td>
                    <td><?php echo e($comuna->mesas); ?></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
        <?php endif; ?>
      </div>

      <?php if($idcom): ?>
      <hr class="style-one" style="margin: 15px 0px 15px 0px">
      <div id="tablaVFilasElectorales" class="row" style="margin-left: 0px; margin-right: 0px"></div>
      <div id="pagVFilasElectorales" class="fixed-table-pagination row" style="margin-left: 0px; margin-right: 0px"></div>
      <div id="ModalPoblacionWrapV"></div>

      <hr class="style-one" style="margin: 15px 0px 15px 0px">
      <div id="tablaVLideres" class="row" style="margin-left: 0px; margin-right: 0px"></div>
      <div id="pagVLideres" class="fixed-table-pagination row" style="margin-left: 0px; margin-right: 0px"></div>
      <?php endif; ?>

      <hr class="style-one">           
      <div id="tablaVResumen" class="row" style="margin-left: 0px; margin-right: 0px"></div>

      <button id="irarriba" type="button" class="btn btn-custom pull-right">Ir arriba</button>
    </div>
  </div>
</div>

<script type="text/javascript">
  var comunasDatos = <?php echo $comunas; ?>;
  var comSelec = <?php echo ($idcom) ? $idcom : 0 ?>;
</script>

<script type="text/javascript" src="<?php echo e(asset('js/mapaMed.js')); ?>"></script>

<?php if($idcom): ?>
<!-- Modal - Editar comuna -->
<div class="modal fade" id="ModalComuna" role="dialog">
  <div class="modal-dialog modal-sm" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Editar comuna</h4>
      </div>
      <?php echo Form::open(['action' => 'MapaMedController@comuna', 'method' => 'POST']); ?>

        <div class="modal-body">
          <?php echo e(Form::hidden('id', '', ['id' => 'idInput'])); ?>

          <?php echo e(Form::label('', 'Puestos')); ?>

          <?php echo e(Form::number('puestos', '', ['id' => 'puestosInput', 'class' => 'form-control'])); ?>

          <?php echo e(Form::label('', 'Barrios')); ?>

          <?php echo e(Form::number('barrios', '', ['id' => 'barriosInput', 'class' => 'form-control'])); ?>

          <?php echo e(Form::label('', 'Mesas')); ?>

          <?php echo e(Form::number('mesas', '', ['id' => 'mesasInput', 'class' => 'form-control'])); ?>

          <?php echo e(Form::hidden('ruta', "Mapa/Med?c=".$comuna->id)); ?>

        </div>
        <div class="modal-footer">
          <?php echo e(Form::submit('Cambiar', ['class' => 'btn btn-danger'])); ?>

        </div>
      <?php echo Form::close(); ?>

    </div>
  </div>
</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>