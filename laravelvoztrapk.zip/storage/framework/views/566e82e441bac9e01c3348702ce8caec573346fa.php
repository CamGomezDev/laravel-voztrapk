<?php $__env->startSection('seccion'); ?>
<script type="text/javascript" src="<?php echo e(asset('js/roles.js')); ?>"></script>
<div class="panel panel-default">
	<div class="panel-heading" id="head">
		<h4>Corporaciones</h4>
	</div>
	<div class="panel-body">
    <?php $import = false; $alt = false; $sec = '';$panelsup = ['Roles','Roles','roles','Rol']; ?>
    <?php echo $__env->make('inc.panel-sup', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="table-responsive">
      <table class="table table-striped table-bordered" style="margin-bottom: 0px">
        <thead>
          <tr>
            <th>Nombre</th>
            <th>Descripción</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
        <?php if($totRows > 0): ?>
          <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($rol->nombre); ?></td>
            <td><?php echo e($rol->descripcion); ?></td>
            <td style="text-align: center">
              <h4 style="margin: 0;">
                <a type="button" data-toggle="modal" data-target="#ModalActualizar"
                  data-id=         "<?php echo e($rol->id); ?>"
                  data-nombre=     "<?php echo e($rol->nombre); ?>"
                  data-descripcion="<?php echo e($rol->descripcion); ?>"><i class="fa fa-pencil-square-o" aria-hidden="true" style="margin-right: 10px"></i></a>
                <a type="button" data-toggle="modal" data-target="#ModalEliminar" data-id="<?php echo e($rol->id); ?>"><i class="fa fa-trash-o" aria-hidden="true"></i></a>
              </h4>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
          <tr>
            <td colspan=3>No se encontraron resultados</td>
          </tr>
        <?php endif; ?>
        </tbody>
      </table>
    </div>
    <?php
    $queryString = [];
    if (isset($_GET['q'])) {
      $queryString['q'] = $_GET['q'];
    } if (isset($_GET['rows'])) {
      $queryString['rows'] = $_GET['rows'];
    } if (isset($_GET['page'])) {
      $queryString['page'] = $_GET['page'];
    }
    ?>
    <?php echo e($roles->appends($queryString)->links()); ?>

    <?php echo $__env->make('inc.filas', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </div>
</div>

<!-- Modal - Crear -->
<div class="modal fade" id="ModalCrear" role="dialog">
  <div class="modal-dialog modal-sm" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Crear Rol</h4>
      </div>
      <?php echo Form::open(['action' => 'RolesController@store', 'method' => 'POST']); ?>

        <div class="modal-body">
          <div class="form-group">
            <?php echo e(Form::label('', 'Nombre')); ?>

            <?php echo e(Form::text('nombre', '', ['class' => 'form-control'])); ?>

            <?php echo e(Form::label('', 'Descripción')); ?>

            <?php echo e(Form::text('descripcion', '', ['class' => 'form-control'])); ?>

          </div>
        </div>
        <div class="modal-footer">
          <?php echo e(Form::submit('Crear', ['class' => 'btn btn-danger'])); ?>

        </div>
      <?php echo Form::close(); ?>

    </div>
  </div>
</div>

<!-- Modal - Actualizar -->
<div class="modal fade" id="ModalActualizar" role="dialog">
  <div class="modal-dialog modal-sm" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Actualizar Rol</h4>
      </div>
      <?php echo Form::open(['action' => ['RolesController@update', 1], 'method' => 'POST']); ?>

        <div class="modal-body">
          <div class="form-group">
            <?php echo e(Form::hidden('id', '', ['id' => 'idInput'])); ?>

            <?php echo e(Form::label('', 'Nombre')); ?>

            <?php echo e(Form::text('nombre', '', ['id' => 'nombreInput', 'class' => 'form-control'])); ?>

            <?php echo e(Form::label('', 'Descripción')); ?>

            <?php echo e(Form::text('descripcion', '', ['id' => 'descripcionInput', 'class' => 'form-control'])); ?>

            <?php echo e(Form::hidden('ruta', url()->current()."?".http_build_query($_GET))); ?>

            <?php echo e(Form::hidden('_method', 'PUT')); ?>

          </div>
        </div>
        <div class="modal-footer">
          <?php echo e(Form::submit('Actualizar', ['class' => 'btn btn-danger'])); ?>

        </div>
      <?php echo Form::close(); ?>

    </div>
  </div>
</div>

<!-- Modal - Eliminar -->
<div class="modal fade" id="ModalEliminar" role="dialog">
  <div class="modal-dialog modal-sm" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Eliminar Rol</h4>
      </div>
      <?php echo Form::open(['action' => 'RolesController@destroy', 'method' => 'POST']); ?>

        <div class="modal-body">
	      	<p>¿Seguro que desea eliminar?</p>
	      	<?php echo e(Form::hidden('id', '', ['id' => 'idInput'])); ?>

          <?php echo e(Form::hidden('ruta', url()->current()."?".http_build_query($_GET))); ?>

	      </div>
        <?php echo e(Form::hidden('_method', 'DELETE')); ?>

        <div class="modal-footer">
          <?php echo e(Form::submit('Sí', ['class' => 'btn btn-danger'])); ?>

        </div>
      <?php echo Form::close(); ?>

    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('pags.ajustes', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>