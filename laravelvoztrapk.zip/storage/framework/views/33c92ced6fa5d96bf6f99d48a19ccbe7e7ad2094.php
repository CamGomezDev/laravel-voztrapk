<?php $__env->startSection('seccion'); ?>
<script type="text/javascript" src="<?php echo e(asset('js/lideres.js')); ?>"></script>
<div class="panel panel-default">
	<div class="panel-heading" id="head">
		<h4>Líderes</h4>
	</div>
	<div class="panel-body">
    <?php $import = true; $alt = true; $panelsup = ['Lideres','Lideres','lideres','Líder']; ?>
    <?php echo $__env->make('inc.panel-sup', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="table-responsive">
      <table class="table table-striped table-bordered" style="margin-bottom: 0px">
        <thead>
          <tr>
            <th>Nombre</th>
            <th>Cédula</th>
            <th>Correo</th>
            <th>Teléfono</th>
            <th>Nivel</th>
            <th>Tipo de líder</th>
            <th>Activo</th>
            <th>Votos estimados</th>
            <th><?php echo e(($sec == 'Med') ? 'Comuna' : 'Municipio'); ?></th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
        <?php if($totRows > 0): ?>
          <?php $__currentLoopData = $lideres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($lider->nombre); ?></td>
            <td><?php echo e($lider->cedula); ?></td>
            <td><?php echo e($lider->correo); ?></td>
            <td><?php echo e($lider->telefono); ?></td>
            <td><?php echo e($lider->nivel); ?></td>
            <td><?php echo e($lider->tipolider); ?></td>
            <td><?php echo ($lider->activo) ? '<i class="fa fa-check" aria-hidden="true" style="color:#31f931"></i>' : '<i class="fa fa-times" aria-hidden="true" style="color:red"></i>'; ?></td>
            <td><?php echo e($lider->votosestimados); ?></td>            
            <td><?php echo e(($sec == 'Med') ? $lider->comuna->nombre : $lider->municipio->nombre); ?></td>
            <td style="text-align: center">
              <h4 style="margin: 0;">
                <a type="button" data-toggle="modal" data-target="#ModalActualizar"
                  data-id=            "<?php echo e($lider->id); ?>"
                  data-nombre=        "<?php echo e($lider->nombre); ?>"
                  data-cedula=        "<?php echo e($lider->cedula); ?>"
                  data-correo=        "<?php echo e($lider->correo); ?>"
                  data-telefono=      "<?php echo e($lider->telefono); ?>"
                  data-nivel=         "<?php echo e($lider->nivel); ?>"
                  data-tipolider=     "<?php echo e($lider->tipolider); ?>"
                  data-votosestimados="<?php echo e($lider->votosestimados); ?>"
                  data-activo=        "<?php echo e($lider->activo); ?>"
                  data-id_municipio=  "<?php echo e(($sec == 'Med') ? $lider->comuna->id : $lider->municipio->id); ?>"><i class="fa fa-pencil-square-o" aria-hidden="true" style="margin-right: 10px"></i></a>
                <a type="button" data-toggle="modal" data-target="#ModalEliminar" data-id="<?php echo e($lider->id); ?>"><i class="fa fa-trash-o" aria-hidden="true"></i></a>
              </h4>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
          <tr>
            <td colspan=10>No se encontraron resultados</td>
          </tr>
        <?php endif; ?>
        </tbody>
      </table>
    </div>
    <?php
    $queryString = [];
    if (isset($_GET['q'])) {
      $queryString['q'] = $_GET['q'];
    } if (isset($_GET['rows'])) {
      $queryString['rows'] = $_GET['rows'];
    } if (isset($_GET['page'])) {
      $queryString['page'] = $_GET['page'];
    }
    ?>
    <?php echo e($lideres->appends($queryString)->links()); ?>

    <?php echo $__env->make('inc.filas', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </div>
</div>

<!-- Modal - Crear -->
<div class="modal fade" id="ModalCrear" role="dialog">
  <div class="modal-dialog modal-sm" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Crear Líder</h4>
      </div>
      <?php echo Form::open(['action' => array('LideresController@store', $sec), 'method' => 'POST']); ?>

        <div class="modal-body">
          <div class="form-group">
            <?php echo e(Form::label('', 'Nombre')); ?>

            <?php echo e(Form::text('nombre', '', ['class' => 'form-control'])); ?>

            <?php echo e(Form::label('', 'Cédula')); ?>

            <?php echo e(Form::text('cedula', '', ['class' => 'form-control'])); ?>

            <?php echo e(Form::label('', 'Correo')); ?>

            <?php echo e(Form::text('correo', '', ['class' => 'form-control'])); ?>

            <?php echo e(Form::label('', 'Teléfono')); ?>

            <?php echo e(Form::text('telefono', '', ['class' => 'form-control'])); ?>

            <?php echo e(Form::label('', 'Nivel')); ?>

            <?php echo e(Form::text('nivel', '', ['class' => 'form-control'])); ?>

            <?php echo e(Form::label('', 'Tipo de líder')); ?>

            <?php echo e(Form::text('tipolider', '', ['class' => 'form-control'])); ?>

            <?php echo e(Form::label('', 'Activo')); ?>

            <?php echo e(Form::select('activo', ['1'=>'Activo', '0'=>'Inactivo'], null, ['class' => 'form-control'])); ?>

            <?php echo e(Form::label('', 'Votos estimados')); ?>

            <?php echo e(Form::number('votosestimados', '', ['class' => 'form-control'])); ?>

            <?php echo e(Form::label('', ($sec == 'Med') ? 'Comuna' : 'Municipio')); ?>

            <?php echo e(Form::select('id_municipio', $seclista, null, ['class' => 'form-control', 'placeholder' => 'Seleccionar '.(($sec == 'Med') ? 'comuna' : 'municipio').'...'])); ?>

          </div>
        </div>
        <div class="modal-footer">
          <?php echo e(Form::submit('Crear', ['class' => 'btn btn-danger'])); ?>

        </div>
      <?php echo Form::close(); ?>

    </div>
  </div>
</div>

<!-- Modal - Actualizar -->
<div class="modal fade" id="ModalActualizar" role="dialog">
  <div class="modal-dialog modal-sm" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Crear Líder</h4>
      </div>
      <?php echo Form::open(['action' => array('LideresController@update', $sec), 'method' => 'POST']); ?>

        <div class="modal-body">
          <div class="form-group">
            <?php echo e(Form::hidden('id', '', ['id' => 'idInput'])); ?>

            <?php echo e(Form::label('', 'Nombre')); ?>

            <?php echo e(Form::text('nombre', '', ['id' => 'nombreInput', 'class' => 'form-control'])); ?>

            <?php echo e(Form::label('', 'Cédula')); ?>

            <?php echo e(Form::text('cedula', '', ['id' => 'cedulaInput', 'class' => 'form-control'])); ?>

            <?php echo e(Form::label('', 'Correo')); ?>

            <?php echo e(Form::text('correo', '', ['id' => 'correoInput', 'class' => 'form-control'])); ?>

            <?php echo e(Form::label('', 'Teléfono')); ?>

            <?php echo e(Form::text('telefono', '', ['id' => 'telefonoInput', 'class' => 'form-control'])); ?>

            <?php echo e(Form::label('', 'Nivel')); ?>

            <?php echo e(Form::text('nivel', '', ['id' => 'nivelInput', 'class' => 'form-control'])); ?>

            <?php echo e(Form::label('', 'Tipo de líder')); ?>

            <?php echo e(Form::text('tipolider', '', ['id' => 'tipoliderInput', 'class' => 'form-control'])); ?>

            <?php echo e(Form::label('', 'Activo')); ?>

            <?php echo e(Form::select('activo', ['1'=>'Activo', '0'=>'Inactivo'], null, ['id' => 'activoInput', 'class' => 'form-control'])); ?>

            <?php echo e(Form::label('', 'Votos estimados')); ?>

            <?php echo e(Form::text('votosestimados', '', ['id' => 'votosestimadosInput', 'class' => 'form-control'])); ?>

            <?php echo e(Form::label('', ($sec == 'Med') ? 'Comuna' : 'Municipio')); ?>

            <?php echo e(Form::select('id_municipio', $seclista, null, ['id' => 'id_municipioInput', 'class' => 'form-control', 'placeholder' => 'Seleccionar '.(($sec == 'Med') ? 'comuna' : 'municipio').'...'])); ?>

            <?php echo e(Form::hidden('ruta', url()->current()."?".http_build_query($_GET))); ?>

            <?php echo e(Form::hidden('_method', 'PUT')); ?>

          </div>
        </div>
        <div class="modal-footer">
          <?php echo e(Form::submit('Actualizar', ['class' => 'btn btn-danger'])); ?>

        </div>
      <?php echo Form::close(); ?>

    </div>
  </div>
</div>

<!-- Modal - Eliminar -->
<div class="modal fade" id="ModalEliminar" role="dialog">
  <div class="modal-dialog modal-sm" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Eliminar líder</h4>
      </div>
      <?php echo Form::open(['action' => 'LideresController@destroy', 'method' => 'POST']); ?>

        <div class="modal-body">
	      	<p>¿Seguro que desea eliminar?</p>
	      	<?php echo e(Form::hidden('id', '', ['id' => 'idInput'])); ?>

          <?php echo e(Form::hidden('ruta', url()->current()."?".http_build_query($_GET))); ?>

	      </div>
        <?php echo e(Form::hidden('_method', 'DELETE')); ?>

        <div class="modal-footer">
          <?php echo e(Form::submit('Sí', ['class' => 'btn btn-danger'])); ?>

        </div>
      <?php echo Form::close(); ?>

    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('pags.administracion', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>