<div id="tablaSFilasElectorales">
  <div class="row vcenter-parent" style="margin: 0px 5px 0px 5px">
    <h4 class="vcenter-parent pull-left">
      <form class="pull-left" action="../ExportarFilasElectoralesMapa<?php echo e(Request::segment(2)); ?>/<?php echo e($idcosa); ?>" method="GET">
        <input type="hidden" name="municnombre" value="">
        <input type="hidden" name="municid" value="">
        <button type="submit" class="btn btn-custom" style="padding-right:7px; padding-left:7px" name="exportarInfosElectoralesMapa"><i class="fa fa-download fa-lg" aria-hidden="true"></i></button>
      </form>
      &nbspInformación Electoral - <?php echo e($cosafrase); ?>

    </h4>
    <?php if($editar): ?>
    <div class="vcenter-parent pull-right" style="margin-left:auto;">
      <button type="button" class="btn btn-custom" data-toggle="modal" data-target="#ModalPoblacion"
        data-id="<?php echo e($cosa->id); ?>" data-poblacion="<?php echo e($cosa->poblacion); ?>">Editar</button>
    </div>
    <?php endif; ?>
  </div>
  <div class="table-responsive">
    <table class="table table-striped table-bordered" style="margin-bottom: 0px; margin-top: 10px">
      <thead>
        <tr>
          <th>Corporación</th>
          <th>Votos totales</th>
          <th>Votos candidato</th>
          <th>Votos partido</th>
          <th>Potencial electoral</th>
          <th>Año</th>
        </tr>
      </thead>
      <tbody>
      <?php if(!(sizeof($filasElectorales))): ?>
        <tr>
          <td colspan=6>Este lugar no tiene información electoral</td>
        </tr>
      <?php endif; ?>
      <?php $__currentLoopData = $filasElectorales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $filaElectoral): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($filaElectoral->corporacion->nombre); ?></td>
          <td><?php echo e($filaElectoral->votostotales); ?></td>
          <td><?php echo e($filaElectoral->votoscandidato); ?></td>
          <td><?php echo e($filaElectoral->votospartido); ?></td>
          <td><?php echo e($filaElectoral->potencialelectoral); ?></td>
          <td><?php echo e($filaElectoral->anio); ?></td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
</div>
<?php $nombreZona = 'FilasElectorales'; $busq = ''; ?>
<?php echo $__env->make('pags.mapa.pagAjax', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<!-- Modal - Población -->
<?php if($editar): ?>
<div id="ModalPoblacionWrapS">
  <div class="modal fade" id="ModalPoblacion" role="dialog">
    <div class="modal-dialog modal-sm" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title">Población de <?php echo e($cosa->nombre); ?></h4>
        </div>
        <?php echo Form::open(['action' => 'MapaAntController@poblacion', 'method' => 'POST']); ?>

          <div class="modal-body">
            <?php echo e(Form::hidden('id', '', ['id' => 'idInput'])); ?>

            <?php echo e(Form::number('poblacion', '', ['id' => 'poblacionInput', 'class' => 'form-control'])); ?>

            <?php echo e(Form::hidden('ruta', "Mapa/Ant?m=".$cosa->id)); ?>

          </div>
          <div class="modal-footer">
            <?php echo e(Form::submit('Cambiar', ['class' => 'btn btn-danger'])); ?>

          </div>
        <?php echo Form::close(); ?>

      </div>
    </div>
  </div>
</div>
<?php endif; ?>