<div id="tablaSResumen">
  <div class="row" style="margin:0px">
    <h4 class="vcenter-parent pull-left" style="margin-left: 5px; text-align: left">
      <form action="../ExportarResumenSub" method="GET">
        <input type="hidden" name="id_corporacion" value="<?php echo e($idcorp); ?>">
        <input type="hidden" name="anio" value="<?php echo e($anio); ?>">
        <button type="submit" class="btn btn-custom" style="padding-right:7px; padding-left:7px" name="exportarResumenMapa"><i class="fa fa-download fa-lg" aria-hidden="true"></i></button>
      </form>
      <span>&nbspResumen por subregión - Votación para</span>
    </h4>
    <h4 class="vcenter-parent pull-left" style="margin-left: 5px; text-align: left">
      <span style="display: inline-block;">
        <span class="btn-group dropdown pull-left" style="position: relative; display: inline-block; vertical-align: middle;">
          <button class="btn btn-default dropdown-toggle" data-toggle="dropdown">
            <h4 style="margin: 0px"><?php echo $corp ?> <span class="caret"></span></h4>
          </button>
          <ul class="dropdown-menu" style="margin: 0px; padding: 0px; border-radius: 2px">
          <?php $__currentLoopData = $corporaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $corporacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($corporacion->id !== $idcorp): ?>
            <li>
              <a href=# style="margin: 3px; padding: 3px;" onclick="conseguirResumen(<?php echo e($corporacion->id); ?>,<?php echo e($anio); ?>); return false">
                <h4 style="margin: 0px; padding: 0px">
                  <?php echo e($corporacion->nombre); ?>

                </h4>
              </a>
            </li>
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </span>
      </span>
      &nbspdel año&nbsp
      <span style="display: inline-block;">
        <span class="btn-group dropdown pull-left" style="position: relative; display: inline-block; vertical-align: middle;">
          <button class="btn btn-default dropdown-toggle" data-toggle="dropdown">
            <h4 style="margin: 0px"><?php echo e($anio); ?> <span class="caret"></span></h4>
          </button>
          <ul class="dropdown-menu" style="margin: 0px; padding: 0px; border-radius: 2px">
          <?php $__currentLoopData = $anios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anioi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($anioi->anio !== $anio): ?>
            <li><a href=# style="margin: 3px; padding: 3px;" onclick="conseguirResumen(<?php echo e($idcorp); ?>,<?php echo e($anioi->anio); ?>); return false"><?php echo e($anioi->anio); ?></a></li>
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </span>
      </span>
    </h4>
  </div>
  <div class="table-responsive">
    <table class="table table-striped table-bordered" style="margin-top:10px">
      <thead>
        <tr>
          <th>Subregión</th>
          <th>Votos totales</th>
          <th>Votos candidato</th>
          <th>Votos partido</th>
          <th>Votos estimados</th>
          <th>Potencial electoral</th>
        </tr>
      </thead>
      <tbody>
      <?php $__currentLoopData = $subregiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subregion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($subregion->id != '1' ): ?>
        <tr>
          <td><a href="Subregion/<?php echo e($subregion->id); ?>"><?php echo e($subregion->nombre); ?></a></td>
          <td><?php echo e($subregion->votostotales); ?></td>
          <td><?php echo e($subregion->votoscandidato); ?></td>
          <td><?php echo e($subregion->votospartido); ?></td>
          <td><?php echo e($subregion->votosestimados); ?></td>
          <td><?php echo e($subregion->potencialelectoral); ?></td>
        </tr>
        <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
</div>