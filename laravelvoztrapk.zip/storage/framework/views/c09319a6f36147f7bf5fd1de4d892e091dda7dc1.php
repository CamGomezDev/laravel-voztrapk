<?php $__env->startSection('seccion'); ?>
<script type="text/javascript" src="<?php echo e(asset('js/compromisos.js')); ?>"></script>
<div class="panel panel-default">
	<div class="panel-heading" id="head">
		<h4>Compromisos</h4>
	</div>
	<div class="panel-body">
    <?php $import = false; $alt = true; $panelsup = ['Compromisos','Compromisos','compromisos','Compromiso']; ?>
    <?php echo $__env->make('inc.panel-sup', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="table-responsive">
      <table class="table table-striped table-bordered" style="margin-bottom: 0px">
        <thead>
          <tr>
            <th>Líder</th>
            <th>Nombre</th>
            <th>Descripción</th>
            <th>Cumplimiento</th>
            <th>Costo</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
        <?php if($totRows > 0): ?>
          <?php $__currentLoopData = $compromisos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $compromiso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($compromiso->lider->nombre); ?></td>
            <td><?php echo e($compromiso->nombre); ?></td>
            <td><?php echo e($compromiso->descripcion); ?></td>
            <td><?php echo ($compromiso->cumplimiento) ? '<i class="fa fa-check" aria-hidden="true" style="color:#31f931"></i>' : '<i class="fa fa-times" aria-hidden="true" style="color:red"></i>'; ?></td>
            <td><?php echo e($compromiso->costo); ?></td>
            <td style="text-align: center">
              <h4 style="margin: 0;">
                <a type="button" data-toggle="modal" data-target="#ModalActualizar"
                  data-id=          "<?php echo e($compromiso->id); ?>"
                  data-id_lider=    "<?php echo e($compromiso->lider->id); ?>"
                  data-nombre=      "<?php echo e($compromiso->nombre); ?>"
                  data-descripcion= "<?php echo e($compromiso->descripcion); ?>"
                  data-cumplimiento="<?php echo e($compromiso->cumplimiento); ?>"
                  data-costo=       "<?php echo e($compromiso->costo); ?>"><i class="fa fa-pencil-square-o" aria-hidden="true" style="margin-right: 10px"></i></a>
                <a type="button" data-toggle="modal" data-target="#ModalEliminar" data-id="<?php echo e($compromiso->id); ?>"><i class="fa fa-trash-o" aria-hidden="true"></i></a>
              </h4>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
          <tr>
            <td colspan=6>No se encontraron resultados</td>
          </tr>
        <?php endif; ?>
        </tbody>
      </table>
    </div>
    <?php
    $queryString = [];
    if (isset($_GET['q'])) {
      $queryString['q'] = $_GET['q'];
    } if (isset($_GET['rows'])) {
      $queryString['rows'] = $_GET['rows'];
    } if (isset($_GET['page'])) {
      $queryString['page'] = $_GET['page'];
    }
    ?>
    <?php echo e($compromisos->appends($queryString)->links()); ?>

    <?php echo $__env->make('inc.filas', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </div>
</div>

<!-- Modal - Crear -->
<div class="modal fade" id="ModalCrear" role="dialog">
  <div class="modal-dialog modal-sm" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Crear Compromiso</h4>
      </div>
      <?php echo Form::open(['action' => 'CompromisosController@store', 'method' => 'POST']); ?>

        <div class="modal-body">
          <div class="form-group">
            <?php echo e(Form::label('', 'Líder')); ?>

            <?php echo e(Form::select('id_lider', $lideres, null, ['class' => 'form-control', 'placeholder' => 'Seleccionar líder en '.$secNom.'...'])); ?>

            <?php echo e(Form::label('', 'Nombre')); ?>

            <?php echo e(Form::text('nombre', '', ['class' => 'form-control'])); ?>

            <?php echo e(Form::label('', 'Descripción')); ?>

            <?php echo e(Form::text('descripcion', '', ['class' => 'form-control'])); ?>

            <?php echo e(Form::label('', 'Cumplimiento')); ?>

            <?php echo e(Form::select('cumplimiento', ['1'=>'Cumplido', '0'=>'Pendiente'], null, ['class' => 'form-control'])); ?>

            <?php echo e(Form::label('', 'Costo')); ?>

            <?php echo e(Form::number('costo', '', ['class' => 'form-control'])); ?>

          </div>
        </div>
        <div class="modal-footer">
          <?php echo e(Form::submit('Crear', ['class' => 'btn btn-danger'])); ?>

        </div>
      <?php echo Form::close(); ?>

    </div>
  </div>
</div>

<!-- Modal - Actualizar -->
<div class="modal fade" id="ModalActualizar" role="dialog">
  <div class="modal-dialog modal-sm" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Crear Compromiso</h4>
      </div>
      <?php echo Form::open(['action' => ['CompromisosController@update', 1], 'method' => 'POST']); ?>

        <div class="modal-body">
          <div class="form-group">
            <?php echo e(Form::hidden('id', '', ['id' => 'idInput'])); ?>

            <?php echo e(Form::label('', 'Líder')); ?>

            <?php echo e(Form::select('id_lider', $lideres, null, ['id' => 'id_liderInput', 'class' => 'form-control', 'placeholder' => 'Seleccionar líder'.$secNom.'...'])); ?>

            <?php echo e(Form::label('', 'Nombre')); ?>

            <?php echo e(Form::text('nombre', '', ['id' => 'nombreInput', 'class' => 'form-control'])); ?>

            <?php echo e(Form::label('', 'Descripción')); ?>

            <?php echo e(Form::text('descripcion', '', ['id' => 'descripcionInput', 'class' => 'form-control'])); ?>

            <?php echo e(Form::label('', 'Cumplimiento')); ?>

            <?php echo e(Form::select('cumplimiento', ['1'=>'Cumplido', '0'=>'Pendiente'], null, ['id' => 'cumplimientoInput', 'class' => 'form-control'])); ?>

            <?php echo e(Form::label('', 'Costo')); ?>

            <?php echo e(Form::number('costo', '', ['id' => 'costoInput', 'class' => 'form-control'])); ?>

            <?php echo e(Form::hidden('ruta', url()->current()."?".http_build_query($_GET))); ?>

            <?php echo e(Form::hidden('_method', 'PUT')); ?>

          </div>
        </div>
        <div class="modal-footer">
          <?php echo e(Form::submit('Actualizar', ['class' => 'btn btn-danger'])); ?>

        </div>
      <?php echo Form::close(); ?>

    </div>
  </div>
</div>

<!-- Modal - Eliminar -->
<div class="modal fade" id="ModalEliminar" role="dialog">
  <div class="modal-dialog modal-sm" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Eliminar compromiso</h4>
      </div>
      <?php echo Form::open(['action' => 'CompromisosController@destroy', 'method' => 'POST']); ?>

        <div class="modal-body">
	      	<p>¿Seguro que desea eliminar?</p>
	      	<?php echo e(Form::hidden('id', '', ['id' => 'idInput'])); ?>

          <?php echo e(Form::hidden('ruta', url()->current()."?".http_build_query($_GET))); ?>

	      </div>
        <?php echo e(Form::hidden('_method', 'DELETE')); ?>

        <div class="modal-footer">
          <?php echo e(Form::submit('Sí', ['class' => 'btn btn-danger'])); ?>

        </div>
      <?php echo Form::close(); ?>

    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('pags.administracion', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>