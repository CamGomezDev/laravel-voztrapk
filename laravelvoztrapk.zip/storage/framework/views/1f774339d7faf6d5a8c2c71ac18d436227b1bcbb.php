<?php if($import): ?>
<div class="row" style="margin:0px 0px 10px 0px">
  <form action="../../Importar/<?php echo e($panelsup[0].Request::segment(2)); ?>" method="POST" enctype="multipart/form-data">
    <input class="pull-left btn btn-custom" style="border-radius:2px" type="file" name="archivo" id="archivo">
    <button class="pull-left btn btn-custom" style="margin-left:5px; padding: 6px 6px 6px 6px" type="submit">
      <i class="fa fa-cloud-upload fa-lg" aria-hidden="true"></i>
    </button>
    <input type="hidden" name="ruta" value="<?php echo e(url()->current()."?".http_build_query($_GET)); ?>">
    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
  </form>
</div>
<?php endif; ?>
<div class="row">
  <div class="pull-left" style="margin-left: 15px;">
    <?php if(Request::segment(1) != 'Ajustes'): ?>
    <?php echo Form::open(['action' => 'ExportExcelController@'.$panelsup[2].(($alt) ? Request::segment(2) : ''), 'method' => 'GET', 'class' => 'pull-left', 'style' => 'margin-bottom: 5px; margin-right: 5px;']); ?>

      <button type="submit" class="btn btn-custom" style="padding-right:7px; padding-left:7px"><i class="fa fa-download fa-lg" aria-hidden="true"></i></button>
    <?php echo Form::close(); ?>

    <?php endif; ?>
    <p class="pull-right">
      <button type="button" class="btn btn-custom" data-toggle="modal" data-target="#ModalCrear"><i class="fa fa-plus" aria-hidden="true"></i> <?php echo e($panelsup[3]); ?></button>
    </p>
  </div>
  <div class="pull-right" style="margin-right: 15px;">
    <?php echo Form::open(['action' => array($panelsup[1].'Controller@index', $sec), 'method' => 'GET']); ?>

      <div class="form-group">
        <?php echo e(Form::text('q', '', ['class' => 'form-control', 'placeholder' => 'Buscar'])); ?>

      </div>
    <?php echo Form::close(); ?>

  </div>
</div>