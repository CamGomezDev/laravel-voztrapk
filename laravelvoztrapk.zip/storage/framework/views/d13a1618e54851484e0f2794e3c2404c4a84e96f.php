<?php $__env->startSection('seccion'); ?>
<script type="text/javascript" src="<?php echo e(asset('js/infoelectoral.js')); ?>"></script>
<div class="panel panel-default">
	<div class="panel-heading" id="head">
		<h4>Información Electoral</h4>
	</div>
	<div class="panel-body">
    <?php $import = true; $alt = true; $panelsup = ['InfoElectoral','FilasElectorales','filasElectorales','Fila Electoral']; ?>
    <?php echo $__env->make('inc.panel-sup', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="table-responsive">
      <table class="table table-striped table-bordered" style="margin-bottom: 0px">
        <thead>
          <tr>
            <th><?php echo e(($sec == 'Med') ? 'Comuna' : 'Municipio'); ?></th>
            <th>Corporación</th>
            <th>Votos totales</th>
            <th>Votos candidato</th>
            <th>Votos partido</th>
            <th>Potencial electoral</th>
            <th>Año</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
        <?php if($totRows > 0): ?>
          <?php $__currentLoopData = $filasElectorales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $filaElectoral): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e(($sec == 'Med') ? $filaElectoral->comuna->nombre : $filaElectoral->municipio->nombre); ?></td>
            <td><?php echo e($filaElectoral->corporacion->nombre); ?></td>
            <td><?php echo e($filaElectoral->votostotales); ?></td>
            <td><?php echo e($filaElectoral->votoscandidato); ?></td>
            <td><?php echo e($filaElectoral->votospartido); ?></td>
            <td><?php echo e($filaElectoral->potencialelectoral); ?></td>
            <td><?php echo e($filaElectoral->anio); ?></td>
            <td style="text-align: center">
              <h4 style="margin: 0;">
                <a type="button" data-toggle="modal" data-target="#ModalActualizar"
                  data-id=                "<?php echo e($filaElectoral->id); ?>"
                  data-id_municipio=      "<?php echo e(($sec == 'Med') ? $filaElectoral->comuna->id : $filaElectoral->municipio->id); ?>"
                  data-id_corporacion=    "<?php echo e($filaElectoral->corporacion->id); ?>"
                  data-votostotales=      "<?php echo e($filaElectoral->votostotales); ?>"
                  data-votoscandidato=    "<?php echo e($filaElectoral->votoscandidato); ?>"
                  data-votospartido=      "<?php echo e($filaElectoral->votospartido); ?>"
                  data-potencialelectoral="<?php echo e($filaElectoral->potencialelectoral); ?>"
                  data-anio=              "<?php echo e($filaElectoral->anio); ?>"><i class="fa fa-pencil-square-o" aria-hidden="true" style="margin-right: 10px"></i></a>
                <a type="button" data-toggle="modal" data-target="#ModalEliminar" data-id="<?php echo e($filaElectoral->id); ?>"><i class="fa fa-trash-o" aria-hidden="true"></i></a>
              </h4>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
          <tr>
            <td colspan=8>No se encontraron resultados</td>
          </tr>
        <?php endif; ?>
        </tbody>
      </table>
    </div>
    <?php
    $queryString = [];
    if (isset($_GET['q'])) {
      $queryString['q'] = $_GET['q'];
    } if (isset($_GET['rows'])) {
      $queryString['rows'] = $_GET['rows'];
    } if (isset($_GET['page'])) {
      $queryString['page'] = $_GET['page'];
    }
    ?>
    <?php echo e($filasElectorales->appends($queryString)->links()); ?>

    <?php echo $__env->make('inc.filas', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </div>
</div>

<!-- Modal - Crear -->
<div class="modal fade" id="ModalCrear" role="dialog">
  <div class="modal-dialog modal-sm" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Crear Fila Electoral</h4>
      </div>
      <?php echo Form::open(['action' => array('FilasElectoralesController@store', $sec), 'method' => 'POST']); ?>

        <div class="modal-body">
          <div class="form-group">
            <?php echo e(Form::label('', ($sec == 'Med') ? 'Comuna' : 'Municipio')); ?>

            <?php echo e(Form::select('id_municipio', $seclista, null, ['class' => 'form-control', 'placeholder' => 'Seleccionar '.(($sec == 'Med') ? 'comuna' : 'municipio').'...'])); ?>

            <?php echo e(Form::label('', 'Corporación')); ?>

            <?php echo e(Form::select('id_corporacion', $corporaciones, null, ['class' => 'form-control', 'placeholder' => 'Seleccionar corporación...'])); ?>

            <?php echo e(Form::label('', 'Votos totales')); ?>

            <?php echo e(Form::number('votostotales', '', ['class' => 'form-control'])); ?>

            <?php echo e(Form::label('', 'Votos candidato')); ?>

            <?php echo e(Form::number('votoscandidato', '', ['class' => 'form-control'])); ?>

            <?php echo e(Form::label('', 'Votos partido')); ?>

            <?php echo e(Form::number('votospartido', '', ['class' => 'form-control'])); ?>

            <?php echo e(Form::label('', 'Potencial electoral')); ?>

            <?php echo e(Form::number('potencialelectoral', '', ['class' => 'form-control'])); ?>

            <?php echo e(Form::label('', 'Año')); ?>

            <?php echo e(Form::number('anio', '', ['class' => 'form-control'])); ?>

          </div>
        </div>
        <div class="modal-footer">
          <?php echo e(Form::submit('Crear', ['class' => 'btn btn-danger'])); ?>

        </div>
      <?php echo Form::close(); ?>

    </div>
  </div>
</div>

<!-- Modal - Actualizar -->
<div class="modal fade" id="ModalActualizar" role="dialog">
  <div class="modal-dialog modal-sm" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Actualizar Fila Electoral</h4>
      </div>
      <?php echo Form::open(['action' => array('FilasElectoralesController@update', $sec), 'method' => 'POST']); ?>

        <div class="modal-body">
          <div class="form-group">
            <?php echo e(Form::hidden('id', '', ['id' => 'idInput'])); ?>

            <?php echo e(Form::label('', ($sec == 'Med') ? 'Comuna' : 'Municipio')); ?>

            <?php echo e(Form::select('id_municipio', $seclista, null, ['id' => 'id_municipioInput', 'class' => 'form-control', 'placeholder' => 'Seleccionar '.($sec == 'Med') ? 'comuna' : 'municipio'.'...'])); ?>

            <?php echo e(Form::label('', 'Corporación')); ?>

            <?php echo e(Form::select('id_corporacion', $corporaciones, null, ['id' => 'id_corporacionInput', 'class' => 'form-control', 'placeholder' => 'Seleccionar corporación...'])); ?>

            <?php echo e(Form::label('', 'Votos totales')); ?>

            <?php echo e(Form::number('votostotales', '', ['id' => 'votostotalesInput', 'class' => 'form-control'])); ?>

            <?php echo e(Form::label('', 'Votos candidato')); ?>

            <?php echo e(Form::number('votoscandidato', '', ['id' => 'votoscandidatoInput', 'class' => 'form-control'])); ?>

            <?php echo e(Form::label('', 'Votos partido')); ?>

            <?php echo e(Form::number('votospartido', '', ['id' => 'votospartidoInput', 'class' => 'form-control'])); ?>

            <?php echo e(Form::label('', 'Potencial electoral')); ?>

            <?php echo e(Form::number('potencialelectoral', '', ['id' => 'potencialelectoralInput', 'class' => 'form-control'])); ?>

            <?php echo e(Form::label('', 'Año')); ?>

            <?php echo e(Form::number('anio', '', ['id' => 'anioInput', 'class' => 'form-control'])); ?>

            <?php echo e(Form::hidden('ruta', url()->current()."?".http_build_query($_GET))); ?>

            <?php echo e(Form::hidden('_method', 'PUT')); ?>

          </div>
        </div>
        <div class="modal-footer">
          <?php echo e(Form::submit('Actualizar', ['class' => 'btn btn-danger'])); ?>

        </div>
      <?php echo Form::close(); ?>

    </div>
  </div>
</div>

<!-- Modal - Eliminar -->
<div class="modal fade" id="ModalEliminar" role="dialog">
  <div class="modal-dialog modal-sm" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Eliminar Fila Electoral</h4>
      </div>
      <?php echo Form::open(['action' => 'FilasElectoralesController@destroy', 'method' => 'POST']); ?>

        <div class="modal-body">
	      	<p>¿Seguro que desea eliminar?</p>
	      	<?php echo e(Form::hidden('id', '', ['id' => 'idInput'])); ?>

          <?php echo e(Form::hidden('ruta', url()->current()."?".http_build_query($_GET))); ?>

	      </div>
        <?php echo e(Form::hidden('_method', 'DELETE')); ?>

        <div class="modal-footer">
          <?php echo e(Form::submit('Sí', ['class' => 'btn btn-danger'])); ?>

        </div>
      <?php echo Form::close(); ?>

    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('pags.administracion', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>