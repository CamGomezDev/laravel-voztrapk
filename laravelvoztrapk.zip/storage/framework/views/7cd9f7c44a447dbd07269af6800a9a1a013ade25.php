<?php $__env->startSection('content'); ?>

<div class="container">
  <div class="panel panel-default">
    <div class="panel-body">
      <div class="row" style="margin-bottom: 15px">
        <button id="irabajo" type="button" class="btn btn-custom pull-right" style="margin-right:15px;">Ir abajo</button>
      </div>

      <div class="row">
        <div class="col-md-8">
          <div class="table-responsive" style="text-align: center; margin-left: 0px; margin-right: 0px">
            <object id='ant_svg' data='<?php echo e(asset('svg/map_antioquia.svg')); ?>' type='image/svg+xml'></object>
          </div>
        </div>
        <div class="col-md-4">
          <div style="margin-left: 0px ; margin-right: 0px">
            <div class="vcenter-parent" style="margin:0px 0px 10px 0px">
              <h4 class="vcenter-parent pull-left">
                &nbsp<?php echo e($subregion->nombre); ?>

              </h4>
            </div>
            <div class="table-responsive">
              <table class="table table-striped table-bordered" style="margin-bottom: 0px">
                <thead>
                  <tr>
                    <th>Líderes</th>
                    <th>Municipios</th>
                    <th>Población</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td><?php echo e(sizeof($subregion->liders)); ?></td>
                    <td><?php echo e(sizeof($subregion->municipios)); ?></td>
                    <td><?php echo e($subregion->poblacion); ?></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      <hr class="style-one" id="inicioTablas" style="margin: 15px 0px 15px 0px">
      <div id="tablaVFilasElectorales" class="row" style="margin-left: 0px; margin-right: 0px"></div>
      <div id="pagVFilasElectorales" class="fixed-table-pagination row" style="margin-left: 0px; margin-right: 0px"></div>
      <div id="ModalPoblacionWrapV"></div>
      
      <hr class="style-one" style="margin: 15px 0px 15px 0px">
      <h4 style="margin: 20px 0px 20px 20px">Municipios en la subregión <?php echo e($subregion->nombre); ?></h4>
      <div class="row" style="margin-left: 0px; margin-right: 0px">
      <?php $__currentLoopData = $municipios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $municipio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="well well-sm" style="display:inline-block"><a href="../Ant?m=<?php echo e($municipio->id); ?>"><?php echo e($municipio->nombre); ?></a></div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>

      <hr class="style-one" style="margin: 15px 0px 15px 0px">
      <div id="tablaVLideres" class="row" style="margin-left: 0px; margin-right: 0px"></div>
      <div id="pagVLideres" class="fixed-table-pagination row" style="margin-left: 0px; margin-right: 0px"></div>

      <button id="irarriba" type="button" class="btn btn-custom pull-right" style="margin-top:20px">Ir arriba</button>
    </div>
  </div>
</div>

<script type="text/javascript">
  var subregionesDatos = <?php echo $subregiones; ?>;
  var subSelec = <?php echo e($idsub); ?>;
</script>

<script type="text/javascript" src="<?php echo e(asset('js/mapaSubs.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>